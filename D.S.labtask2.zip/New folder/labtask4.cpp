#include<iostream>
using namespace std;
int main()
{
    int n =10;
    cout<<"Enter the size of this array: "<<endl;
    cin>>n;
    int arr[n];
    cout<<"Enter the elements of this array: "<<endl;
    for(int i=0;i<n;i++)
    {

        cout<<arr[i]<<"  ";
    }
    cout<<endl;
    int ran=0,a;
    cout<<"Enter the number to the serached: "<<endl;
    cin>>a;
    for(int i=0;i<n;i++)
    {
        if(arr[i]==a)
        {
            ran++;
        }
    }



    cout<<"The number occurs"<<ran<<"time in array"<<endl;




    return 0;
}
