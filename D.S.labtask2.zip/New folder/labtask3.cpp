#include<iostream>
using namespace std;
int main()
{
    int n;
    cout<<"Enter the elements of this array: "<<endl;
    cin>>n;
    int arr[n];
    cout<<"Enter the elements of the array: "<<endl;
    for(int i=0;i<n;i++)
    {
        cin>>arr[i];
    }

    cout<<"The array: ";
    for(int i=0;i<n;i++)
    {
        cout<<arr[i]<<"  ";
    }
    cout<<endl;
    int arr1[n];
    int ran = 0,z=2;
    for(int i=0; i<n;i++)
    {
       bool d=false;
        for(int j=i+1;j<n;j++)
        {

            if(arr[i]==arr[j])
            {
                d=true;
                break;
            }
        }
        if(!d)
            {
                arr1[ran]=arr[i];;
                ran++;


            }

        }

    if(ran>0)
    {


        for(int i=0;i<ran;i++)
        {
            cout<<arr1[i]<<"  ";
        }
    }
      else
      {


            cout<<"ay already unique!"<<endl;
        }










    return 0;
}
